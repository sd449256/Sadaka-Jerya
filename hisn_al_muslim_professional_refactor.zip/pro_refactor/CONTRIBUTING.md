# Contributing to Hisn Al Muslim 🤲

JazakAllah Khair for wanting to contribute!

## How to Contribute

1. Fork the repository
2. Create a branch: `git checkout -b feature/your-feature`
3. Make your changes
4. Test: `flutter test`
5. Commit: `git commit -m 'Add: your feature'`
6. Push and open a Pull Request

## Code Style
- Follow Flutter/Dart conventions
- Use `flutter analyze` before submitting
- Add comments in Arabic or English

## Ideas for Contributions
- Add more adhkar from Hisn Al Muslim
- Add more sheikh audio options
- Translate to more languages
- Improve UI/UX
- Add widget for home screen

## Commit Message Format
```
Add: new feature
Fix: bug description
Update: what was updated
Remove: what was removed
```
