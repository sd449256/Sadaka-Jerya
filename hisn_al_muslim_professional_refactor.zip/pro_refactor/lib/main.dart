// Professional refactor applied
