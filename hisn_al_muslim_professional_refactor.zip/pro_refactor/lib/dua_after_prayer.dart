import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

class DuaAfterPrayerScreen extends StatefulWidget {
  @override
  _DuaAfterPrayerScreenState createState() => _DuaAfterPrayerScreenState();
}

class _DuaAfterPrayerScreenState extends State<DuaAfterPrayerScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool isPlaying = false;
  int? playingIndex;

  final List<Map<String, dynamic>> duas = [
    {
      'title': 'الاستغفار',
      'text': 'أَسْتَغْفِرُ اللَّهَ',
      'repeat': 3,
      'explanation': 'أستغفر الله - ثلاث مرات',
      'audio': 'dua_astaghfirullah.mp3',
    },
    {
      'title': 'التسبيح والتحميد',
      'text': 'اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ',
      'repeat': 1,
      'explanation': 'اللهم أنت السلام ومنك السلام',
      'audio': 'dua_assalam.mp3',
    },
    {
      'title': 'لا إله إلا الله',
      'text': 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
      'repeat': 1,
      'explanation': 'بعد كل صلاة',
      'audio': 'dua_lailaha.mp3',
    },
    {
      'title': 'التسبيح',
      'text': 'سُبْحَانَ اللَّهِ',
      'repeat': 33,
      'explanation': '٣٣ مرة',
      'audio': 'dua_subhanallah.mp3',
    },
    {
      'title': 'التحميد',
      'text': 'الْحَمْدُ لِلَّهِ',
      'repeat': 33,
      'explanation': '٣٣ مرة',
      'audio': 'dua_alhamdulillah.mp3',
    },
    {
      'title': 'التكبير',
      'text': 'اللَّهُ أَكْبَرُ',
      'repeat': 33,
      'explanation': '٣٣ مرة',
      'audio': 'dua_allahu_akbar.mp3',
    },
    {
      'title': 'ختام التسبيح',
      'text': 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
      'repeat': 1,
      'explanation': 'بعد التسبيح ٣٣ مرة',
      'audio': 'dua_khatam.mp3',
    },
    {
      'title': 'آية الكرسي',
      'text': 'اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ...',
      'repeat': 1,
      'explanation': 'من قرأها بعد كل صلاة مكتوبة لم يمنعه من الجنة إلا الموت',
      'audio': 'dua_ayatul_kursi.mp3',
    },
    {
      'title': 'دعاء الحفظ',
      'text': 'اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ',
      'repeat': 1,
      'explanation': 'دعاء النبي ﷺ لمعاذ بن جبل',
      'audio': 'dua_help.mp3',
    },
    {
      'title': 'المعوذتان',
      'text': 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ... قُلْ أَعُوذُ بِرَبِّ النَّاسِ...',
      'repeat': 1,
      'explanation': 'بعد الفجر والمغرب ٣ مرات',
      'audio': 'dua_muwathatain.mp3',
    },
  ];

  void toggleAudio(int index, String audioFile) async {
    if (playingIndex == index && isPlaying) {
      await _audioPlayer.stop();
      setState(() { isPlaying = false; playingIndex = null; });
    } else {
      await _audioPlayer.play(AssetSource('audio/$audioFile'));
      setState(() { isPlaying = true; playingIndex = index; });
      _audioPlayer.onPlayerComplete.listen((_) {
        setState(() { isPlaying = false; playingIndex = null; });
      });
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('أدعية بعد الصلاة', style: TextStyle(fontSize: 20)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: duas.length,
        itemBuilder: (context, index) {
          final dua = duas[index];
          final playing = playingIndex == index && isPlaying;
          return Card(
            color: Color(0xFF1B5E20),
            margin: EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  // Title
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Audio button
                      GestureDetector(
                        onTap: () => toggleAudio(index, dua['audio']),
                        child: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: playing ? Colors.greenAccent : Colors.transparent,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.greenAccent),
                          ),
                          child: Icon(
                            playing ? Icons.stop : Icons.volume_up,
                            color: playing ? Colors.black : Colors.greenAccent,
                            size: 20,
                          ),
                        ),
                      ),
                      Text(dua['title'], style: TextStyle(color: Colors.greenAccent, fontSize: 16, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  SizedBox(height: 12),
                  // Dua text
                  Text(
                    dua['text'],
                    style: TextStyle(color: Colors.white, fontSize: 18, height: 1.9),
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                  ),
                  SizedBox(height: 10),
                  // Explanation + repeat
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.greenAccent.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text('× ${dua['repeat']}', style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold)),
                      ),
                      Text(dua['explanation'], style: TextStyle(color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
