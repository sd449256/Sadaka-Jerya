import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TasbihScreen extends StatefulWidget {
  @override
  _TasbihScreenState createState() => _TasbihScreenState();
}

class _TasbihScreenState extends State<TasbihScreen> {
  int count = 0;
  int total = 0;
  int target = 33;
  int round = 1;

  final List<Map<String, dynamic>> dhikrList = [
    {'text': 'سُبْحَانَ اللَّهِ', 'count': 33},
    {'text': 'الْحَمْدُ لِلَّهِ', 'count': 33},
    {'text': 'اللَّهُ أَكْبَرُ', 'count': 33},
    {'text': 'لَا إِلَهَ إِلَّا اللَّهُ', 'count': 100},
    {'text': 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ', 'count': 100},
  ];

  int selectedDhikr = 0;

  void increment() {
    HapticFeedback.lightImpact();
    setState(() {
      count++;
      total++;
      if (count >= target) {
        count = 0;
        round++;
        HapticFeedback.heavyImpact();
      }
    });
  }

  void reset() {
    setState(() {
      count = 0;
      total = 0;
      round = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('المسبحة', style: TextStyle(fontSize: 22)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
        actions: [
          IconButton(icon: Icon(Icons.refresh), onPressed: reset)
        ],
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: Column(
        children: [
          // Dhikr selector
          SizedBox(height: 16),
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16),
              itemCount: dhikrList.length,
              itemBuilder: (context, index) {
                final selected = index == selectedDhikr;
                return GestureDetector(
                  onTap: () => setState(() {
                    selectedDhikr = index;
                    target = dhikrList[index]['count'];
                    count = 0;
                    round = 1;
                  }),
                  child: Container(
                    margin: EdgeInsets.only(right: 8),
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected ? Colors.greenAccent : Color(0xFF1B5E20),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      dhikrList[index]['text'],
                      style: TextStyle(
                        color: selected ? Colors.black : Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 20),
          // Current dhikr text
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              dhikrList[selectedDhikr]['text'],
              style: TextStyle(color: Colors.white, fontSize: 28, height: 1.8),
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
            ),
          ),
          SizedBox(height: 30),
          // Counter display
          Text('$count', style: TextStyle(color: Colors.greenAccent, fontSize: 80, fontWeight: FontWeight.bold)),
          Text('/ $target', style: TextStyle(color: Colors.white54, fontSize: 24)),
          SizedBox(height: 8),
          Text('الجولة: $round  |  الإجمالي: $total', style: TextStyle(color: Colors.white70, fontSize: 16)),
          SizedBox(height: 40),
          // Big tap button
          GestureDetector(
            onTap: increment,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF1B5E20),
                border: Border.all(color: Colors.greenAccent, width: 3),
                boxShadow: [BoxShadow(color: Colors.greenAccent.withOpacity(0.3), blurRadius: 20, spreadRadius: 5)],
              ),
              child: Center(
                child: Text('اضغط', style: TextStyle(color: Colors.white, fontSize: 24)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
