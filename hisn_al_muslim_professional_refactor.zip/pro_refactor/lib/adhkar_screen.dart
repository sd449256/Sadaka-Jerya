import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';

class AdhkarScreen extends StatefulWidget {
  final String category;
  final String title;
  AdhkarScreen({required this.category, required this.title});

  @override
  _AdhkarScreenState createState() => _AdhkarScreenState();
}

class _AdhkarScreenState extends State<AdhkarScreen> {
  List<dynamic> adhkarList = [];
  Map<int, int> counters = {};
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    loadAdhkar();
  }

  Future<void> loadAdhkar() async {
    final String data = await rootBundle.loadString('assets/data/adhkar.json');
    final Map<String, dynamic> json = jsonDecode(data);
    setState(() {
      adhkarList = json[widget.category] ?? [];
      for (var i = 0; i < adhkarList.length; i++) {
        counters[i] = adhkarList[i]['count'];
      }
    });
  }

  void playAudio(String audioFile) async {
    await _audioPlayer.play(AssetSource('audio/$audioFile'));
  }

  void decrementCounter(int index) {
    setState(() {
      if (counters[index]! > 0) {
        counters[index] = counters[index]! - 1;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, style: TextStyle(fontSize: 20)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: adhkarList.length,
        itemBuilder: (context, index) {
          final dhikr = adhkarList[index];
          return Card(
            color: Color(0xFF1B5E20),
            margin: EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    dhikr['text'],
                    style: TextStyle(color: Colors.white, fontSize: 18, height: 1.8),
                    textAlign: TextAlign.right,
                    textDirection: TextDirection.rtl,
                  ),
                  SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Play audio button
                      IconButton(
                        icon: Icon(Icons.volume_up, color: Colors.greenAccent),
                        onPressed: () => playAudio(dhikr['audio']),
                      ),
                      // Counter
                      GestureDetector(
                        onTap: () => decrementCounter(index),
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                          decoration: BoxDecoration(
                            color: counters[index] == 0 ? Colors.grey : Colors.greenAccent,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '${counters[index]}',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
