import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'dart:math';

class QiblaScreen extends StatefulWidget {
  @override
  _QiblaScreenState createState() => _QiblaScreenState();
}

class _QiblaScreenState extends State<QiblaScreen> {
  double qiblaAngle = 0;
  bool loading = true;

  // Kaaba coordinates
  final double kaabaLat = 21.4225;
  final double kaabaLng = 39.8262;

  @override
  void initState() {
    super.initState();
    calculateQibla();
  }

  Future<void> calculateQibla() async {
    Position pos = await Geolocator.getCurrentPosition();
    double lat1 = pos.latitude * pi / 180;
    double lat2 = kaabaLat * pi / 180;
    double dLng = (kaabaLng - pos.longitude) * pi / 180;

    double y = sin(dLng) * cos(lat2);
    double x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLng);
    double angle = atan2(y, x) * 180 / pi;

    setState(() {
      qiblaAngle = (angle + 360) % 360;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('اتجاه القبلة', style: TextStyle(fontSize: 22)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: Center(
        child: loading
            ? CircularProgressIndicator(color: Colors.greenAccent)
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Transform.rotate(
                    angle: qiblaAngle * pi / 180,
                    child: Icon(Icons.navigation, color: Colors.greenAccent, size: 120),
                  ),
                  SizedBox(height: 30),
                  Text('اتجاه القبلة', style: TextStyle(color: Colors.white, fontSize: 24)),
                  SizedBox(height: 10),
                  Text('${qiblaAngle.toStringAsFixed(1)}°', style: TextStyle(color: Colors.greenAccent, fontSize: 32, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  Text('وَمِنْ حَيْثُ خَرَجْتَ فَوَلِّ وَجْهَكَ شَطْرَ الْمَسْجِدِ الْحَرَامِ',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.rtl,
                  ),
                ],
              ),
      ),
    );
  }
}
