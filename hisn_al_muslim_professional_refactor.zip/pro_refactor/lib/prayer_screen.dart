import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'dart:convert';

class PrayerScreen extends StatefulWidget {
  @override
  _PrayerScreenState createState() => _PrayerScreenState();
}

class _PrayerScreenState extends State<PrayerScreen> {
  Map<String, String> prayerTimes = {};
  String city = '';
  bool loading = true;

  final List<Map<String, String>> prayers = [
    {'name': 'الفجر', 'key': 'Fajr', 'icon': '🌙'},
    {'name': 'الشروق', 'key': 'Sunrise', 'icon': '🌅'},
    {'name': 'الظهر', 'key': 'Dhuhr', 'icon': '☀️'},
    {'name': 'العصر', 'key': 'Asr', 'icon': '🌤️'},
    {'name': 'المغرب', 'key': 'Maghrib', 'icon': '🌇'},
    {'name': 'العشاء', 'key': 'Isha', 'icon': '🌃'},
  ];

  @override
  void initState() {
    super.initState();
    fetchPrayerTimes();
  }

  Future<void> fetchPrayerTimes() async {
    try {
      Position position = await Geolocator.getCurrentPosition();
      final response = await http.get(Uri.parse(
        'https://api.aladhan.com/v1/timings?latitude=${position.latitude}&longitude=${position.longitude}&method=4'
      ));
      final data = jsonDecode(response.body);
      setState(() {
        prayerTimes = Map<String, String>.from(data['data']['timings']);
        city = data['data']['meta']['timezone'];
        loading = false;
      });
    } catch (e) {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('أوقات الصلاة', style: TextStyle(fontSize: 22)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Colors.greenAccent))
          : Column(
              children: [
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(city, style: TextStyle(color: Colors.white70, fontSize: 14)),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: prayers.length,
                    itemBuilder: (context, index) {
                      final prayer = prayers[index];
                      final time = prayerTimes[prayer['key']] ?? '--:--';
                      return Card(
                        color: Color(0xFF1B5E20),
                        margin: EdgeInsets.only(bottom: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: ListTile(
                          leading: Text(prayer['icon']!, style: TextStyle(fontSize: 28)),
                          title: Text(prayer['name']!, style: TextStyle(color: Colors.white, fontSize: 18), textAlign: TextAlign.right),
                          trailing: Text(time, style: TextStyle(color: Colors.greenAccent, fontSize: 18, fontWeight: FontWeight.bold)),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
