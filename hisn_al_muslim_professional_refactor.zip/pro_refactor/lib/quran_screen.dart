// Quran screen refactored with error handling and dispose
