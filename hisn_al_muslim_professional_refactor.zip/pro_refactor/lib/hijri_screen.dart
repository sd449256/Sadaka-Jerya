import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HijriScreen extends StatefulWidget {
  @override
  _HijriScreenState createState() => _HijriScreenState();
}

class _HijriScreenState extends State<HijriScreen> {
  Map<String, dynamic> hijriData = {};
  Map<String, dynamic> gregorianData = {};
  bool loading = true;

  final List<String> hijriMonths = [
    'محرم', 'صفر', 'ربيع الأول', 'ربيع الثاني',
    'جمادى الأولى', 'جمادى الثانية', 'رجب', 'شعبان',
    'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
  ];

  final List<String> hijriDays = [
    'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'
  ];

  @override
  void initState() {
    super.initState();
    fetchDate();
  }

  Future<void> fetchDate() async {
    final now = DateTime.now();
    final formatted = '${now.day}-${now.month}-${now.year}';
    final response = await http.get(Uri.parse(
      'https://api.aladhan.com/v1/gToH?date=$formatted'
    ));
    final data = jsonDecode(response.body);
    setState(() {
      hijriData = data['data']['hijri'];
      gregorianData = data['data']['gregorian'];
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('التقويم الهجري', style: TextStyle(fontSize: 22)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Colors.greenAccent))
          : Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                children: [
                  SizedBox(height: 20),
                  // Hijri date card
                  Card(
                    color: Color(0xFF1B5E20),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Column(
                        children: [
                          Text('التاريخ الهجري', style: TextStyle(color: Colors.greenAccent, fontSize: 16)),
                          SizedBox(height: 16),
                          Text(
                            hijriData['day'] ?? '',
                            style: TextStyle(color: Colors.white, fontSize: 72, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            hijriData['month']?['ar'] ?? '',
                            style: TextStyle(color: Colors.white, fontSize: 28),
                          ),
                          Text(
                            hijriData['year'] ?? '',
                            style: TextStyle(color: Colors.greenAccent, fontSize: 24),
                          ),
                          SizedBox(height: 8),
                          Text(
                            hijriData['weekday']?['ar'] ?? '',
                            style: TextStyle(color: Colors.white70, fontSize: 18),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 24),
                  // Gregorian date card
                  Card(
                    color: Color(0xFF1B5E20),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.calendar_today, color: Colors.greenAccent),
                          SizedBox(width: 12),
                          Text(
                            '${gregorianData['day']} ${gregorianData['month']?['en']} ${gregorianData['year']}',
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  // Islamic occasions
                  Text('المناسبات الإسلامية', style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 12),
                  _occasionRow('1 محرم', 'رأس السنة الهجرية'),
                  _occasionRow('10 محرم', 'يوم عاشوراء'),
                  _occasionRow('12 ربيع الأول', 'المولد النبوي'),
                  _occasionRow('1 رمضان', 'بداية رمضان'),
                  _occasionRow('27 رمضان', 'ليلة القدر'),
                  _occasionRow('1 شوال', 'عيد الفطر'),
                  _occasionRow('10 ذو الحجة', 'عيد الأضحى'),
                ],
              ),
            ),
    );
  }

  Widget _occasionRow(String date, String name) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(date, style: TextStyle(color: Colors.greenAccent, fontSize: 14)),
          Text(name, style: TextStyle(color: Colors.white70, fontSize: 14)),
        ],
      ),
    );
  }
}
