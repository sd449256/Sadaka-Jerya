<div align="center">

# 📿 Hisn Al Muslim — حصن المسلم

**A complete Islamic companion app built with Flutter**

[![Flutter](https://img.shields.io/badge/Flutter-3.x-blue?logo=flutter)](https://flutter.dev)
[![Dart](https://img.shields.io/badge/Dart-3.x-blue?logo=dart)](https://dart.dev)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](CONTRIBUTING.md)

بسم الله الرحمن الرحيم

</div>

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🕌 Prayer Times | Live GPS-based prayer times via Aladhan API |
| 📖 Quran | Full Quran with Sheikh Mishary Alafasy audio |
| 🧭 Qibla Direction | Accurate Qibla calculated from your location |
| 📿 Tasbih | Digital counter with haptic feedback |
| 🗓️ Hijri Calendar | Today's Hijri date + Islamic occasions |
| 🤲 Dua After Prayer | 10 complete duas with optional audio |
| 🌅 Morning Adhkar | أذكار الصباح with counter + audio |
| 🌙 Evening Adhkar | أذكار المساء with counter + audio |
| 🛏️ Sleep Adhkar | أذكار النوم with counter + audio |

---

## 📱 Screenshots

> _Add screenshots here after building the app_

| Home | Prayer Times | Quran | Tasbih |
|------|-------------|-------|--------|
| ![Home](docs/screenshots/home.png) | ![Prayer](docs/screenshots/prayer.png) | ![Quran](docs/screenshots/quran.png) | ![Tasbih](docs/screenshots/tasbih.png) |

---

## 🚀 Getting Started

### Prerequisites

- Flutter SDK >= 3.0.0
- Dart SDK >= 3.0.0
- Android Studio or VS Code
- Android/iOS device or emulator

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/hisn-al-muslim.git

# Navigate to project
cd hisn-al-muslim

# Install dependencies
flutter pub get

# Run the app
flutter run
```

---

## 📡 APIs Used

| API | Purpose | Docs |
|-----|---------|------|
| [Aladhan](https://aladhan.com/prayer-times-api) | Prayer times + Hijri date | Free |
| [AlQuran Cloud](https://alquran.cloud/api) | Quran text + audio | Free |

---

## 🏗️ Project Structure

```
lib/
├── main.dart                 # App entry + home screen
├── prayer_screen.dart        # Prayer times
├── quran_screen.dart         # Quran browser + audio
├── qibla_screen.dart         # Qibla direction
├── tasbih_screen.dart        # Digital tasbih
├── hijri_screen.dart         # Hijri calendar
├── dua_after_prayer.dart     # Post-prayer duas
└── adhkar_screen.dart        # Morning/evening/sleep adhkar

assets/
├── audio/                    # Sheikh recitation MP3s
├── data/
│   └── adhkar.json           # Adhkar content
└── fonts/
    └── Amiri-Regular.ttf     # Arabic font
```

---

## 🤝 Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) first.

1. Fork the repo
2. Create your branch: `git checkout -b feature/amazing-feature`
3. Commit: `git commit -m 'Add amazing feature'`
4. Push: `git push origin feature/amazing-feature`
5. Open a Pull Request

---

## 📄 License

MIT License — see [LICENSE](LICENSE)

---

<div align="center">

**اللَّهُمَّ اجْعَلْنَا مِنَ الذَّاكِرِينَ**

Made with ❤️ for the Muslim Ummah

*Sadaqa Jariya — صدقة جارية*

</div>
