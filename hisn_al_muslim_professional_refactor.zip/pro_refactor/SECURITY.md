# Security Policy 🔒

## Reporting a Vulnerability

If you discover a security vulnerability, please do NOT open a public issue.

Email: security@yourapp.com

We will respond within 48 hours.

## Security Recommendations for Users
- Always download from official sources (Play Store / App Store)
- Keep the app updated
- The app does NOT collect any personal data
- All API calls are read-only and public
- No user accounts or passwords required

## Data Privacy
- Location is used ONLY for prayer times and Qibla calculation
- No data is stored on external servers
- No analytics or tracking
