---
name: Bug Report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior.

**Expected behavior**
What you expected to happen.

**Screenshots**
If applicable, add screenshots.

**Device info:**
- Device: [e.g. Samsung S21]
- OS: [e.g. Android 13]
- App Version: [e.g. 1.0.0]
