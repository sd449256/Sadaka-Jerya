# Changelog

All notable changes to this project will be documented here.

## [1.0.0] - 2026-05-15

### Added
- 🕌 Prayer times with GPS location
- 📖 Full Quran with Sheikh Mishary audio
- 🧭 Qibla direction calculator
- 📿 Digital Tasbih counter with haptic feedback
- 🗓️ Hijri calendar with Islamic occasions
- 🤲 Dua after prayer with optional audio
- 🌅 Morning Adhkar (أذكار الصباح)
- 🌙 Evening Adhkar (أذكار المساء)
- 🛏️ Sleep Adhkar (أذكار النوم)
- 🎨 Beautiful dark green Islamic theme
