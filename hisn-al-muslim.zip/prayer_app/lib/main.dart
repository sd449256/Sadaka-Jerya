import 'package:flutter/material.dart';
import 'prayer_screen.dart';
import 'adhkar_screen.dart';
import 'quran_screen.dart';
import 'qibla_screen.dart';
import 'tasbih_screen.dart';
import 'hijri_screen.dart';
import 'dua_after_prayer.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حصن المسلم',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF1B5E20),
        scaffoldBackgroundColor: Color(0xFF0D3B1E),
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> categories = [
      {'title': 'أوقات الصلاة', 'icon': Icons.mosque, 'type': 'prayer'},
      {'title': 'القرآن الكريم', 'icon': Icons.menu_book, 'type': 'quran'},
      {'title': 'اتجاه القبلة', 'icon': Icons.explore, 'type': 'qibla'},
      {'title': 'المسبحة', 'icon': Icons.circle_outlined, 'type': 'tasbih'},
      {'title': 'التقويم الهجري', 'icon': Icons.calendar_month, 'type': 'hijri'},
      {'title': 'أدعية بعد الصلاة', 'icon': Icons.volunteer_activism, 'type': 'dua'},
      {'title': 'أذكار الصباح', 'icon': Icons.wb_sunny, 'type': 'adhkar', 'category': 'morning'},
      {'title': 'أذكار المساء', 'icon': Icons.nightlight_round, 'type': 'adhkar', 'category': 'evening'},
      {'title': 'أذكار النوم', 'icon': Icons.bed, 'type': 'adhkar', 'category': 'sleep'},
    ];

    return Scaffold(
      backgroundColor: Color(0xFF0D3B1E),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 24),
            Text('حصن المسلم', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('بسم الله الرحمن الرحيم', style: TextStyle(color: Colors.greenAccent, fontSize: 18)),
            SizedBox(height: 24),
            Expanded(
              child: GridView.builder(
                padding: EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                ),
                itemCount: categories.length,
                itemBuilder: (context, index) {
                  final cat = categories[index];
                  return GestureDetector(
                    onTap: () {
                      Widget screen;
                      switch (cat['type']) {
                        case 'prayer': screen = PrayerScreen(); break;
                        case 'quran': screen = QuranScreen(); break;
                        case 'qibla': screen = QiblaScreen(); break;
                        case 'tasbih': screen = TasbihScreen(); break;
                        case 'hijri': screen = HijriScreen(); break;
                        case 'dua': screen = DuaAfterPrayerScreen(); break;
                        default: screen = AdhkarScreen(category: cat['category'], title: cat['title']);
                      }
                      Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
                    },
                    child: Card(
                      color: Color(0xFF1B5E20),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(cat['icon'], color: Colors.greenAccent, size: 44),
                          SizedBox(height: 10),
                          Text(cat['title'], style: TextStyle(color: Colors.white, fontSize: 15), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(12),
              child: Text('اللَّهُمَّ اجْعَلْنَا مِنَ الذَّاكِرِينَ', style: TextStyle(color: Colors.white38, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }
}
