import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'dart:convert';

class QuranScreen extends StatefulWidget {
  @override
  _QuranScreenState createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  List<dynamic> surahs = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchSurahs();
  }

  Future<void> fetchSurahs() async {
    final response = await http.get(Uri.parse('https://api.alquran.cloud/v1/surah'));
    final data = jsonDecode(response.body);
    setState(() {
      surahs = data['data'];
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('القرآن الكريم', style: TextStyle(fontSize: 22)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Colors.greenAccent))
          : ListView.builder(
              itemCount: surahs.length,
              itemBuilder: (context, index) {
                final surah = surahs[index];
                return ListTile(
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Color(0xFF1B5E20),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text('${surah['number']}', style: TextStyle(color: Colors.greenAccent, fontSize: 12)),
                    ),
                  ),
                  title: Text(surah['name'], style: TextStyle(color: Colors.white, fontSize: 18), textAlign: TextAlign.right),
                  subtitle: Text(surah['englishName'], style: TextStyle(color: Colors.white54)),
                  trailing: Text('${surah['numberOfAyahs']} آية', style: TextStyle(color: Colors.greenAccent)),
                  onTap: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => SurahScreen(surahNumber: surah['number'], surahName: surah['name']),
                  )),
                );
              },
            ),
    );
  }
}

class SurahScreen extends StatefulWidget {
  final int surahNumber;
  final String surahName;
  SurahScreen({required this.surahNumber, required this.surahName});

  @override
  _SurahScreenState createState() => _SurahScreenState();
}

class _SurahScreenState extends State<SurahScreen> {
  List<dynamic> ayahs = [];
  bool loading = true;
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    fetchSurah();
  }

  Future<void> fetchSurah() async {
    // ar.alafasy = Sheikh Mishary Alafasy audio
    final response = await http.get(Uri.parse(
      'https://api.alquran.cloud/v1/surah/${widget.surahNumber}/ar.alafasy'
    ));
    final data = jsonDecode(response.body);
    setState(() {
      ayahs = data['data']['ayahs'];
      loading = false;
    });
  }

  void playAyah(String audioUrl) async {
    await _audioPlayer.play(UrlSource(audioUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surahName, style: TextStyle(fontSize: 22)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFF0D3B1E),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Colors.greenAccent))
          : ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: ayahs.length,
              itemBuilder: (context, index) {
                final ayah = ayahs[index];
                return Card(
                  color: Color(0xFF1B5E20),
                  margin: EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          ayah['text'],
                          style: TextStyle(color: Colors.white, fontSize: 20, height: 2.0),
                          textAlign: TextAlign.right,
                          textDirection: TextDirection.rtl,
                        ),
                        SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              icon: Icon(Icons.play_circle, color: Colors.greenAccent, size: 32),
                              onPressed: () => playAyah(ayah['audio']),
                            ),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.greenAccent,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text('${ayah['numberInSurah']}', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
